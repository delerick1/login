import { useState, useEffect } from 'react'

export default function PunchIn() {
  const [currentTime, setCurrentTime] = useState(new Date())
  const [punchStatus, setPunchStatus] = useState('out') // 'in' or 'out'
  const [lastPunchTime, setLastPunchTime] = useState(null)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  const handlePunch = () => {
    const now = new Date()
    setLastPunchTime(now)
    setPunchStatus(punchStatus === 'out' ? 'in' : 'out')
  }

  const formatTime = (date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    })
  }

  const formatDate = (date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
          Time Clock
        </h2>

        {/* Current Time Display */}
        <div className="text-center mb-8">
          <div className="text-4xl font-mono font-bold text-gray-800 mb-2">
            {formatTime(currentTime)}
          </div>
          <div className="text-lg text-gray-600">
            {formatDate(currentTime)}
          </div>
        </div>

        {/* Punch Status */}
        <div className="text-center mb-8">
          <div className={`inline-flex items-center px-4 py-2 rounded-full text-sm font-medium ${
            punchStatus === 'in' 
              ? 'bg-green-100 text-green-800' 
              : 'bg-red-100 text-red-800'
          }`}>
            <div className={`w-2 h-2 rounded-full mr-2 ${
              punchStatus === 'in' ? 'bg-green-500' : 'bg-red-500'
            }`}></div>
            Currently Punched {punchStatus === 'in' ? 'In' : 'Out'}
          </div>
        </div>

        {/* Last Punch Time */}
        {lastPunchTime && (
          <div className="text-center mb-8 p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600 mb-1">Last punch time:</p>
            <p className="font-medium text-gray-800">
              {formatTime(lastPunchTime)} on {formatDate(lastPunchTime)}
            </p>
          </div>
        )}

        {/* Punch Button */}
        <div className="text-center">
          <button
            onClick={handlePunch}
            className={`px-8 py-4 rounded-lg font-semibold text-white text-lg transition-colors ${
              punchStatus === 'out'
                ? 'bg-green-600 hover:bg-green-700'
                : 'bg-red-600 hover:bg-red-700'
            }`}
          >
            Punch {punchStatus === 'out' ? 'In' : 'Out'}
          </button>
        </div>

        {/* Today's Summary */}
        <div className="mt-8 p-4 bg-blue-50 rounded-lg">
          <h3 className="font-semibold text-blue-800 mb-2">Today's Summary</h3>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-blue-600">First Punch In:</span>
              <p className="font-medium">--:--</p>
            </div>
            <div>
              <span className="text-blue-600">Last Punch Out:</span>
              <p className="font-medium">--:--</p>
            </div>
            <div>
              <span className="text-blue-600">Total Hours:</span>
              <p className="font-medium">0:00</p>
            </div>
            <div>
              <span className="text-blue-600">Break Time:</span>
              <p className="font-medium">0:00</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}